INFORMASI KELOMPOK:
Habil Putra Wardana (00000073909) (habil.putra@student.umn.ac.id, Informatika)
Rifqi Arief Wicaksana (00000073943) (rifqi.arief1@student.umn.ac.id, Informatika)

GitHub Link:
https://github.com/N4AD/Kelompok3-FL.git

Gameplay Note:
- Seperti game idle clicker yang ada, di klik icon yang ada di dalam game (Mobil Tahu Bulat)
- Skor merupakan Money yang kita hasilkan
- Harga awal tahu bulat adalah 1
- Terdapat Modifier Repeatable dan Non-Repeatable

Harga Upgrades:
Upgrade Tahu Bulat	: 500 (non-repeatable)
Upgrade Sotong		: 50000 (non-repeatable)
Upgrade Babi		: 5000000 (non-repeatable)
Upgrade Auto Clicker	: Auto Clicker akan naik harga setiap dibeli sebesar x1.5. (repeatable)
dan Upgrade Cabang	: Upgrade Cabang akan naik harga setiap dibeli sebesar x2.5. (repeatable)

Modifier:
Disini akan terdapat 5 button yang dapat diinteraksi yaitu: 
Upgrade Tahu Bulat	: Harga awal tahu bulat akan menaik sebesar x1.25.
Upgrade Sotong		: Harga awal tahu bulat akan menaik sebesar x1.5.
Upgrade Babi		: Harga awal tahu bulat akan menaik sebesar  x1.75.
Upgrade Auto Clicker	: Auto Clicker akan bertambah 1.
dan Upgrade Cabang	: Harga awal tahu bulat akan menambah sebesar 2.
